#include <stdio.h>
#include <math.h>
int sum (int n1, int n2, int flag);
int multi (int n1, int n2, int flag);
int isprime(int a);
void write_file (int number);
void print_file();
void sort_file();


//-------------------------------------------------------------------------------------------------------------------------------

int sum (int n1, int n2, int flag){  // sum function
int k=n1;
int a=0;
if(flag == 0){
  if(k%2==1 || k%2==-1){  // making sure we're working on evens.
  k=k+1;
  }
	while(1){
	   
		if(k>n1){
		a=a+k;	
		}
		if(k+2>=n2){
		return a;
		}
	k=k+2;
	}
	
  }
if(flag==1){
	if(k%2==0 || k%2==0){  // making sure we're working on odds.
  			k=k+1;
  			}
	while(1){
	   
		if(k>n1){
		a=a+k;
		}
		if(k+2>=n2){
		return a;
		}
	k=k+2;
	}
 }

} // end of sum

//-------------------------------------------------------------------------------------------------------------------------------

int multi (int n1, int n2, int flag){   // multiplication function.
int k=n1;
int a=1;
if(flag == 0){
if(k%2==1 || k%2==-1){  // making sure we're working on evens.
  k=k+1;
  }
	while(1){
	   
		if(k>n1){
		a=a*k;
		}
		if(k+2>=n2){
		return a;
		}
	k=k+2;
	}
	
  }
if(flag==1){
	if(k%2==0 || k%2==0){  // making sure we're working on odds.
  			k=k+1;
  			}
	while(1){
	   
		if(k>n1){
		a=a*k;
		}
		if(k+2>=n2){
		return a;
		}
	k=k+2;
	}
 }

}   // end of multi

//-------------------------------------------------------------------------------------------------------------------------------

int isprime(int a){
int x,y;
for(x=2;x<=sqrt(a);x++){
	if(a%x==0){
	return x; // return the least divisor of that integer if it is NOT prime
	
	}
	

}
return a;  // return the integer itself if it is prime

}

//-------------------------------------------------------------------------------------------------------------------------------

void write_file (int number){ // our writing file that is used in part 1 in order to get results
FILE *fl;
fl=fopen("results.txt","a");
fprintf(fl,"%d ",number);
fclose(fl);
}

//-------------------------------------------------------------------------------------------------------------------------------

void print_file(){ // simply prints file data
int min1,min2,min3;
FILE *fl;
fl=fopen("results.txt","r");
fscanf(fl,"%d",&min1);
	while(!feof (fl)){
	printf("%d ",min1);
	fscanf(fl,"%d",&min1);
	}
}

//-------------------------------------------------------------------------------------------------------------------------------
 void sort_file(){
 FILE *fl;
FILE *temp;
fl=fopen("results.txt","r");  // our main results file
temp=fopen("temp.txt","w"); // temporary file


long long int i=0,j=0,k=0;  // they stand for controlling. given to the min1,min2,min3 3 number by 3 respectively and restarts loop
long long int check_size,size=0;
long long int getnum=0;  // variable we are gonna use in reading temp file
fscanf(fl,"%lld",&check_size);	
	while(!feof (fl)){ // loop for indicating size of results file
	fscanf(fl,"%lld",&check_size);
	size++;
	}
fclose(fl);
long long int min1,min2,min3;



for(i=0;i<10000000;i++)		{ // min1 part, round starts
fl=fopen("results.txt","r");
	while(!feof(fl)){
	fscanf(fl,"%lld",&min1);
		if(i==min1){  // min 1 gets smallest number for this round
	
		if(size!=1){
		fprintf(temp,"%lld ",min1);
		}
		else fprintf(temp,"%lld",min1);
		size--;
		if(size==0){ // end if all numbers are scanned
		fclose(fl);
		fl=fopen("results.txt","w");
		fclose(temp);
		temp=fopen("temp.txt","r");
			while(!feof(temp)){
			fscanf(temp,"%lld",&getnum);
			printf("%lld ",getnum);
			fprintf(fl,"%lld ",getnum);	
			}
				
				printf("\n");	
		fclose(fl);
		fclose(temp);
	
		return ;
	

		}
			for(j=i+1;j<10000000;j++){  // min2 part
			fl=fopen("results.txt","r");
				while(!feof(fl)){
				fscanf(fl,"%lld",&min2);
					if(j==min2){   // min2 gets second smallest number for this round
					
					if(size!=1){
					fprintf(temp,"%lld ",min2);
					}
					else fprintf(temp,"%lld",min2);
					size--;
					if(size==0){ 	// end if all numbers are scanned
					fclose(fl);
					fl=fopen("results.txt","w");
					fclose(temp);
					temp=fopen("temp.txt","r");
						while(!feof(temp)){
						fscanf(temp,"%lld",&getnum);
						printf("%lld ",getnum);
						fprintf(fl,"%lld ",getnum);	
						}
							
					printf("\n");
					fclose(fl);
					fclose(temp);
					return ;
					}
						for(k=j+1;k<10000000;k++){	// min3 part
						fl=fopen("results.txt","r");
							while(!feof(fl)){
							fscanf(fl,"%lld",&min3);
								if(k==min3){   // min3 gets third smallest number for this round
								
									if(size!=1){
									fprintf(temp,"%lld ",min3);
									}
									else {
									fprintf(temp,"%lld",min3);
									}
								size--;
								i=k+1; // changing very first loop variable to the up-to-date number 
								
								
								
								if(size==0){ 	// end if all numbers are scanned
								fclose(fl);
								fl=fopen("results.txt","w");
								fclose(temp);
								temp=fopen("temp.txt","r");
									while(!feof(temp)){
									fscanf(temp,"%lld",&getnum);
									printf("%lld ",getnum);
									fprintf(fl,"%lld ",getnum);	
									}
										
								printf("\n");
								fclose(fl);
								fclose(temp);
								return ;
	

								}
								k=9999999;  // these are needed to end -j and k loops- and -round- so 3 by 3 logic won't give error
								j=9999999;
		
								}
		
							}



						}
					}
		
				}



			}  // these are some nice brackets
			
		}
		
	}



}




}
 
 
 

//-------------------------------------------------------------------------------------------------------------------------------

int main() {

FILE *fl;
fl=fopen("results.txt","a");

printf("Select operation\n1. Calculate sum/multiplication between two numbers\n2. Calculate prime numbers\n3. Show number sequence in file\n4. Sort number sequence in file\n-----------------------\n");

int selection;
scanf("%d",&selection);
if(selection==1){  // part 1 

	printf("Please enter '0' for sum, '1' for multiplication.\n");
	int flagslc;
	scanf("%d",&flagslc);

	printf("Please enter '0' to work on even numbers, '1' to work on odd numbers.\n");
	int eoslc;  // even-odd numbers selection
	scanf("%d",&eoslc);

	int a1,a2;
	printf("Please enter two different number\n");
	printf("Number 1: ");
	scanf("%d",&a1);
	printf("Number 2: ");
	scanf("%d",&a2);
	switch(flagslc){
// case 0 starts -------------------------------------------------------------------------------------------------------------------------------
		case 0:
		printf("Result\n");
if(eoslc==0){		
int k=a1;
int a=1;
if(k%2==1 || k%2==-1){  // making sure we're working on evens.
  k=k+1;
  }
	while(1){
	   
		if(k>a1){
		a=a+k;
			if(k+2<a2){
			printf("%d + ",k);
			}
			else printf("%d = ",k);
		}
		if(k+2>=a2){
		break;
		}
	k=k+2;
	}
}
if(eoslc==1){
int k=a1;
int a=1;	
	if(k%2==0 || k%2==0){  // making sure we're working on odds.
  			k=k+1;
  			}
	while(1){
	   
		if(k>a1){
		a=a+k;
			if(k+2<a2){
			printf("%d + ",k);
			}
			else printf("%d = ",k);
		}
		if(k+2>=a2){
		break;
		}
	k=k+2;
	}
 }
		
		printf("%d\nThe result is written to the results.txt file.\n",sum(a1,a2,eoslc));
		write_file(sum(a1,a2,eoslc));   // write file function
		break;
// case 0 ends -------------------------------------------------------------------------------------------------------------------------------


// case 1 starts -------------------------------------------------------------------------------------------------------------------------------		
		case 1:
		printf("Result\n");
int k=a1;
int a=1;
if(eoslc == 0){
if(k%2==1 || k%2==-1){  // making sure we're working on evens.
  k=k+1;
  }
	while(1){
	   
		if(k>a1){
		a=a*k;
			if(k+2<a2){
			printf("%d * ",k);
			}
			else printf("%d = ",k);
		}
		if(k+2>=a2){
		break;
		}
	k=k+2;
	}
	
  }
if(eoslc==1){
	if(k%2==0 || k%2==0){  // making sure we're working on odds.
  			k=k+1;
  			}
	while(1){
	   
		if(k>a1){
		a=a*k;
			if(k+2<a2){
			printf("%d * ",k);
			}
			else printf("%d = ",k);
		
		}
		if(k+2>=a2){
		break;
		}
	k=k+2;
	}
 }
		printf("%d\nThe result is written to the results.txt file.\n",multi(a1,a2,eoslc)); 
		write_file(multi(a1,a2,eoslc));
		break;
		}
		
// case 1 ends -------------------------------------------------------------------------------------------------------------------------------
		
}  // end of part 1

if(selection==2){ // part 2 -------------------------------------------------------------------------------------------------------------------------------
printf("Please enter an integer: ");
int N;   // get input from user
scanf("%d",&N);
int i;   // for loop
for(i=2;i<N;i++){
	if(i==isprime(i)){
	printf("%d is a prime number.\n",i);
	}
	else printf("%d is not a prime number, it is dividible by %d.\n",i,isprime(i));

  }
}

if(selection==3){ // part 3  -------------------------------------------------------------------------------------------------------------------------------
printf("Result : \n");
print_file();
printf("\n");
}

if(selection==4){
printf("Sorting is complete.\n");
printf("Result : \n");
sort_file();
printf("\n");
}



 
  
 // end of part 3 -------------------------------------------------------------------------------------------------------------------------------




return 0;
}
