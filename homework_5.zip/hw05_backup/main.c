#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI 3.14

int select_shape();
int select_calc();
int calc_triangle(int a);
int calc_quadrilateral(int a);
int calc_circle(int a);
int calc_pyramid(int a);
int calc_cylinder(int a);
void clean_stdin(void)
{
    int c;
    do {
        c = getchar();
    } while (c != '\n' && c != EOF);
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
enum shapes{
Triangle=1,Quadrilateral,Circle,Pyramid,Cylinder  // 1,2,3,4,5
};

enum calculators{
Area=1,Perimeter,Volume  // 1,2,3
};

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
int calc_triangle(int a){ 
	switch(a){
	case 0:
		return 0;
	
	case 1:
		printf("Please enter three sides of Triangle:\n"); //-------------------------
		double a1,a2,a3;
		if(scanf("%lf",&a1)){    // this if-else-fflush part in every scanf functions written in this project, is intended to only take integers, not chars etc..
		}
		else{
		printf("ERROR! Please enter a valid entry.");     //--------------------------
		clean_stdin();
		break;
		}
		if(scanf("%lf",&a2)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&a3)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		double s;
		s=(a1+a2+a3)/2;
		if(a1+a2<=a3 || abs(a1-a2)>=a3 ||a3+a2<=a1 || abs(a3-a2)>=a1 || a1+a3<=a2 || abs(a1-a3)>=a2 || a1<=0 || a2<=0 || a3<=0){ // triangle logic and negativity part
		printf("ERROR! Please enter a valid triangle.\n");
		break;
		}
		printf("Area of TRIANGLE : %.2f",sqrt( s*(s-a1)*(s-a2)*(s-a3) ) );

		break;
	case 2:
		printf("Please enter three sides of Triangle:\n");
		double p1,p2,p3;
		if(scanf("%lf",&p1)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&p2)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&p3)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(p1+p2<=p3 || abs(p1-p2)>=p3 ||p3+p2<=p1 || abs(p3-p2)>=p1 || p1+p3<=p2 || abs(p1-p3)>=p2 || p1<=0 || p2<=0 || p3<=0){ // triangle logic and negativity part
		printf("ERROR! Please enter a valid triangle.\n");
		break;
		}
		printf("Perimeter of TRIANGLE: %.2f\n\n",p1+p2+p3);
		break;	
	case 3:
		printf("ERROR! You cannot calculate the volume of a triangle. Please try again.\n\n");
		break;
	
	
	default:
		printf("ERROR! Please enter a valid entry.");
	
	}
return 1;
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
int calc_quadrilateral(int a){
	switch(a){
	
	case 0:
		return 0;
	
	case 1:
		printf("Please enter four sides of Quadrilateral:\n");
		double q1,q2,q3,q4;
		if(scanf("%lf",&q1)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&q2)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&q3)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&q4)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(q1<=0 || q2<=0 || q3<=0 || q4<=0 )
			{ 
			printf("ERROR! Please enter a valid entry.");
			break;
			
			}
		double q;
		q=(q1+q2+q3+q4)/2;
		printf("Area of QUADRILATERAL : %.2f",sqrt( (q-q1)*(q-q2)*(q-q3)*(q-q4) ) );

		break;
	case 2:
		printf("Please enter four sides of Quadrilateral:\n");
		double qa1,qa2,qa3,qa4;
		if(scanf("%lf",&qa1)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&qa2)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&qa3)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&qa4)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(qa1<=0 || qa2<=0 || qa3<=0 || qa4<=0 )
			{ 
			printf("ERROR! Please enter a valid entry.");
			break;
			
			}
		printf("Perimeter of the QUADRILATERAL is: %.2f\n\n",qa1+qa2+qa3+qa4);
		break;	
	case 3:
		printf("ERROR! You cannot calculate the volume of a quadrilateral. Please try again.\n\n");
		break;
	
	default:
		printf("ERROR! Please enter a valid entry.");
	
	
	}
	return 1;
}


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

int calc_circle(int a){
	switch(a){
	
	case 0:
		return 0;
	
	case 1:
		printf("Please enter the radius of Circle:\n");
		double r;
		if(scanf("%lf",&r)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(r<=0)
			{ 
			printf("ERROR! Please enter a valid entry.");
			break;
			
			}
		double area;
		area=PI*r*r;
		printf("Area of CIRCLE : %.2f",area );

		break;
	case 2:
		printf("Please enter the radius of Circle:\n");
		double r1;
		if(scanf("%lf",&r1)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(r1<=0)
			{ 
			printf("ERROR! Please enter a valid entry.");
			break;
			
			}
		printf("Perimeter of the CIRCLE is: %.2f\n\n",2*PI*r1);
		break;	
	case 3:
		printf("ERROR! You cannot calculate the volume of a circle. Please try again.\n\n");
		break;
	
	default:
		printf("ERROR! Please enter a valid entry.");
 }
return 1;
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
int calc_pyramid(int a){
	switch(a){
	
	case 0:
		return 0;
	
	case 1:
		printf("Please enter the base side and height of a Pyramid :\n");
		double side,hei;
		if(scanf("%lf",&side)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&hei)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(side<=0 || hei<=0)
			{ 
			printf("ERROR! Please enter a valid entry.");
			break;
			
			}
		printf("Base Surface Area of a PYRAMID: %.2f\n",side*side);
		printf("Lateral Surface Area of a PYRAMID: %.2f\n",2*side*hei);
		printf("Surface Area of a PYRAMID: %.2f\n",(side*side) + (2*side*hei) );
	
		break;
	case 2:
		printf("Please enter the base side of a Pyramid:\n");
		double r1;
		if(scanf("%lf",&r1)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(r1<=0)
			{ 
			printf("ERROR! Please enter a valid entry.");
			break;
			
			}
		printf("Perimeter of the PYRAMID is: %.2f\n\n",4*r1);
		break;	
	case 3:
		printf("Please enter the base side and height of a Pyramid :\n");
		double side1,hei1;
		if(scanf("%lf",&side1)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&hei1)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(side1<=0 || hei1<=0)
			{ 
			printf("ERROR! Please enter a valid entry.");
			break;
			
			}
		printf("Volume of a PYRAMID: %.2f",(side1*side1*hei1)/3 );
		break;
	
	
	default:
		printf("ERROR! Please enter a valid entry.");
	
 }
 return 1;
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
int calc_cylinder(int a){
	switch(a){
	
	case 0:
		return 0;
	
	case 1:
		printf("Please enter the radius and height of a Cylinder :\n");
		double r,hei;
		if(scanf("%lf",&r)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&hei)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
			if(r<=0 || hei<=0)
			{ 
			printf("ERROR! Please enter a valid entry.");
			break;
			
			}
		printf("Base Surface Area of a CYLINDER: %.2f\n",PI*r*r);
		printf("Lateral Surface Area of a CYLINDER: %.2f\n",2*PI*r*hei);
		printf("Surface Area of a CYLINDER: %.2f\n",2*PI*r*(r+hei) );
	
		break;
	case 2:
		printf("Please enter the radius and height of a Cylinder :\n");
		double r1,hei1;
		if(scanf("%lf",&r1)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&hei1)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(r1<=0 || hei1<=0)
			{ 
			printf("ERROR! Please enter a valid entry.");
			break;
			
			}
		printf("Perimeter of the is: %.2f\n\n",2*PI*r1);
		break;	
	case 3:
		printf("Please enter the radius and height of a Cylinder :\n");
		double r2,hei2;
		if(scanf("%lf",&r2)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(scanf("%lf",&hei2)){
		}
		else{
		printf("ERROR! Please enter a valid entry.");
		clean_stdin();
		break;
		}
		if(r2<=0 || hei2<=0)
			{ 
			printf("ERROR! Please enter a valid entry.");
			break;
			
			}
		printf("Volume of a CYLINDER: %.2f",PI*r2*r2*hei2);
		break;
	default:
		printf("ERROR! Please enter a valid entry.");
	
 }
return 1;

}
//~~~~~~~~~~~~~~~~~~
int select_shape(){ // shape selection that returns shape number (1-->triangle, 2-->quad ...) 

int a;
if(scanf("%d",&a)){
return a;
}
else{
clean_stdin();
return -1;
}


}
//~~~~~~~~~~~~~~~~~~
int select_calc(){ // calculation selection that returns calc number (1--> area, 2--> perimeter, 3--> volume)
int b;
if(scanf("%d",&b)){
	return b;		
		}
		else{
		
		clean_stdin();
		return -1; // for valid character selection in calculation menu
		}

}
//~~~~~~~~~~~~~~~~~~
int calculate(int (*a)(int),int (*b)(int)){
enum shapes shape;
enum calculators calc;

do{
printf("\n\nSelect shape to calculate:\n--------------------------\n1. Triangle\n2. Quadrilateral\n3. Circle\n4. Pyramid\n5. Cylinder\n0. Exit\n------------------------\nInput : ");

shape=a(0); //using a() function to get shape selection

switch(shape){

case Triangle: //buradasın
printf("Select calculator:\n------------------------\n1. Area\n2. Perimeter\n3. Volume\n0. Exit\n-----------------\nInput :");
calc=b(0); //using b() function to get calculation selection
if(calc_triangle(calc)==0){
 return 0;
 }
break;

case Quadrilateral:
printf("Select calculator:\n------------------------\n1. Area\n2. Perimeter\n3. Volume\n0. Exit\n-----------------\nInput :");
calc=b(0); //using b() function to get calculation selection
if(calc_quadrilateral(calc)==0){
 return 0;
 }
break;

case Circle:
printf("Select calculator:\n------------------------\n1. Area\n2. Perimeter\n3. Volume\n0. Exit\n-----------------\nInput :");
calc=b(0); //using b() function to get calculation selection
if(calc_circle(calc)==0){
 return 0;
 }
break;

case Pyramid:
printf("Select calculator:\n------------------------\n1. Area\n2. Perimeter\n3. Volume\n0. Exit\n-----------------\nInput :");
calc=b(0); //using b() function to get calculation selection
if(calc_pyramid(calc)==0){
 return 0;
 }
break;

case Cylinder:
printf("Select calculator:\n------------------------\n1. Area\n2. Perimeter\n3. Volume\n0. Exit\n-----------------\nInput :");
calc=b(0); //using b() function to get calculation selection
if(calc_cylinder(calc)==0){
 return 0;
 }
break;



default:
if(shape!=0) printf("You've entered invalid character.");
break;
  }

 }while(shape!=0);
}
//~~~~~~~~~~~~~~~~~~

int main(){



calculate(select_shape,select_calc);






return 0;

}
