#include <stdio.h>
#include "util.h"
#include <string.h>





int main() {

printf("\n\n\t********* PART I ***********\n\n"); //beginning of part 1.1

int x,y,z;
printf("Enter the first integer: ");
scanf("%d", &x);

printf("Enter the second integer: ");
scanf("%d", &y);

printf("Enter the divisor: ");
scanf("%d", &z);

find_divisible(x,y,z); // using the function

if(find_divisible(x,y,z)!=(-1)){				// first successful operation
		
	printf("The first integer between %d and %d divided by %d is %d",x,y,z,find_divisible(x,y,z)); 

	int n,f_i; // beginning of part 1.2

	printf("\n\nEnter the number how many next: ");


	scanf("%d",&n);


		if( find_nth_divisible( n, find_divisible(x,y,z),z ) < y  ){


		printf(" The %d. integer between %d and %d divided by %d is ",n+1,x,y,z);

		printf("%d\n\n\n", find_nth_divisible(n, find_divisible(x,y,z) , z)); //using second function that uses first function's return value as it's input
	
							}

		else	{

		printf("The value you are looking for is not between %d and %d.",x,y);


	}
}		
if(find_divisible(x,y,z)==-1){			// failed operation
		
		printf("There are not any integers can be divided by %d between %d and %d.\n\n\n",z,x,y);  
		
		}

// *********************************************************** 

printf("\n\n\t********* PART II ***********\n\n");   // beginning of part 2.1

char identity_number[100]; 
printf("Enter your identity number:");
scanf("%s",identity_number);

validate_identity_number(identity_number);         // using the function

int password;

printf("Enter your password: ");
scanf("%d",&password);

	if(password>9999 || password<1000){     // making sure that password has 4 digits,neglecting the scenario of the first digit being zero
	printf("Invalid identity number or password.");

	return 0;


	}

if(validate_identity_number(identity_number) == 1){    // beginning of part 2.2

create_customer(identity_number,password);          // using the function

printf("You've created your account successfully.");

// *************************************************************

printf("\n\n\t********* PART III ***********\n\n");     // beginning of part 3.1

printf("Enter your identity number to login:");    

char identity_number_login[11];

scanf("%s",identity_number_login);   // reading identity number from user again to log them in

int password_login;

printf("Enter your password to login:"); 

scanf("%d",&password_login);

check_login( identity_number_login , password_login );   // using function

	if(check_login( identity_number_login , password_login ) == -1){
	printf("Invalid identity number or password.");
					}
	else		{
 	printf("Login successful"); 
	
	printf("\n\nEnter your withdraw amount: ");
	float cash_amount;
	scanf("%f",&cash_amount);
	withdrawable_amount(cash_amount); // using function
	printf("\nWithdrawable amount is: %d",withdrawable_amount(cash_amount));  // using function's return output to demonstrate withdrawable amount
	
		}


	}

else		{

printf("Invalid identity number or password.");

}
return 0;
}


