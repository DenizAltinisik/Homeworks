#include <stdio.h>
#include "util.h"
#include <string.h>
int find_divisible(int x, int y, int z){  // first function
int i; 
for(i=x+1;i<y;i++){
	if(i%z == 0){
		return i;
		
		
	}
	
	

}
return -1;		
	    
	 

}
/* ******************************************************************************** */


int find_nth_divisible(int n,int f_i,int z){ // second function
int result;
result= f_i + (n)*z;

return result;
}

/* ******************************************************************************** */

int validate_identity_number(char identity_number [ ]) { // third function


int Check_Len = 0; // checking the lenght of identity number
  while (identity_number [Check_Len] != '\0'){
    Check_Len++;
}


	if(Check_Len == 11){  
	
	
	
		}

	else{

	
	return -1;

	}


int i;
for(i=0;i<=10;i++){
	if((int)identity_number[i]<48 || (int)identity_number[i]>57){  // checking if the inputs are between 0 and 9 or not
	
	return -1;

						}

					}
	
		if(identity_number[0]==48){  // checking first digit to not to be zero
		return -1;
				}		
	






int a,b;
a=7*(identity_number[0] + identity_number[2] + identity_number[4] + identity_number[6] + identity_number[8] - (5*48)) - (identity_number[1] + identity_number[3] + identity_number[5] + identity_number[7] - (4*48) );
b=identity_number[9]-48;   // subtracting the sum of the digits 2, 4, 6, 8 from 7 times the sum of the digits 1, 3, 5, 7, 9


if(b!=a%10){ 						// checking remainder and 10th digit equality

return -1;
}


int k,c=0;				// c stands for the total sum of first 10 digits
for(k=0;k<10;k++){
c=c + identity_number[k] - 48;


}

	if(c%10 + 48 != identity_number[10]){
	
	return -1;
	}

return 1;
}

/* ******************************************************************************** */

int create_customer(char identity_number [ ], int password){    // fourth function

FILE *fp;

fp=fopen("customeraccount.txt","w"); 		// creating file for storing datas of customer's, in "write" mode
 
fprintf(fp,"%s,%d",identity_number,password);  // printing identity number and password to the customeraccount.txt file, respectively

fclose(fp);

}

/* ******************************************************************************** */

int check_login(char identity_number [ ], int password){   // fifth function

FILE *fpa;

fpa=fopen("customeraccount.txt","r");     //  opening customer's data file to receive identity number and password

char validate_identity[11];
int pass;
fscanf(fpa,"%[^,]%*c %d",validate_identity,&pass);     // receive identity number and password from file 
int sayac;

for(sayac=0;sayac<11;sayac++){       // checking if the saved number catches with the input login number
	
	if(identity_number[sayac] != (validate_identity[sayac]) ){
			
	return -1;
}


}					



if(password != pass){  	// password control

return -1;

}

		

fclose(fpa);

return 1;
}

/* ******************************************************************************** */

int withdrawable_amount(float cash_amount){ // sixth function
int a;			
a=cash_amount;		// getting rid of the numbers after floating point

int rem; 		//stands for remainder
rem=a%10;
a=a-rem;		// making ones digit zero


return a;    // making functions value 'a' to print it on main code
}








